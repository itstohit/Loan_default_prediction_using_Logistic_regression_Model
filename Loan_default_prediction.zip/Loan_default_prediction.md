```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import statsmodels.api as sm
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

```


```python
df = pd.read_csv(r"C:\Users\User\OneDrive\Documents\4. Github Project & Dataset\python project\sorted_data.csv")
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_paid_back</th>
      <th>education_level</th>
      <th>monthly_income</th>
      <th>employment_status</th>
      <th>debt_to_income_ratio</th>
      <th>credit_score</th>
      <th>loan_amount</th>
      <th>interest_rate</th>
      <th>loan_term</th>
      <th>installment</th>
      <th>num_of_open_accounts</th>
      <th>total_credit_limit</th>
      <th>current_balance</th>
      <th>delinquency_history</th>
      <th>public_records</th>
      <th>num_of_delinquencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Master's</td>
      <td>2020.02</td>
      <td>Employed</td>
      <td>0.07</td>
      <td>743</td>
      <td>17173.72</td>
      <td>13.39</td>
      <td>36</td>
      <td>581.88</td>
      <td>7</td>
      <td>40833.47</td>
      <td>24302.07</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Bachelor's</td>
      <td>1681.08</td>
      <td>Employed</td>
      <td>0.22</td>
      <td>531</td>
      <td>22663.89</td>
      <td>17.81</td>
      <td>60</td>
      <td>573.17</td>
      <td>5</td>
      <td>27968.01</td>
      <td>10803.01</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>High School</td>
      <td>2181.82</td>
      <td>Employed</td>
      <td>0.23</td>
      <td>779</td>
      <td>3631.36</td>
      <td>9.53</td>
      <td>60</td>
      <td>76.32</td>
      <td>2</td>
      <td>15502.25</td>
      <td>4505.44</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>High School</td>
      <td>989.49</td>
      <td>Employed</td>
      <td>0.26</td>
      <td>809</td>
      <td>14939.23</td>
      <td>7.99</td>
      <td>36</td>
      <td>468.07</td>
      <td>7</td>
      <td>18157.79</td>
      <td>5525.63</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>Other</td>
      <td>2110.54</td>
      <td>Employed</td>
      <td>0.26</td>
      <td>663</td>
      <td>16551.71</td>
      <td>15.20</td>
      <td>60</td>
      <td>395.50</td>
      <td>1</td>
      <td>17467.56</td>
      <td>3593.91</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 20000 entries, 0 to 19999
    Data columns (total 16 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   loan_paid_back        20000 non-null  int64  
     1   education_level       20000 non-null  object 
     2   monthly_income        20000 non-null  float64
     3   employment_status     20000 non-null  object 
     4   debt_to_income_ratio  20000 non-null  float64
     5   credit_score          20000 non-null  int64  
     6   loan_amount           20000 non-null  float64
     7   interest_rate         20000 non-null  float64
     8   loan_term             20000 non-null  int64  
     9   installment           20000 non-null  float64
     10  num_of_open_accounts  20000 non-null  int64  
     11  total_credit_limit    20000 non-null  float64
     12  current_balance       20000 non-null  float64
     13  delinquency_history   20000 non-null  int64  
     14  public_records        20000 non-null  int64  
     15  num_of_delinquencies  20000 non-null  int64  
    dtypes: float64(7), int64(7), object(2)
    memory usage: 2.4+ MB
    


```python
df.value_counts("education_level") 
```




    education_level
    Bachelor's     8045
    High School    5919
    Master's       3724
    Other          1508
    PhD             804
    Name: count, dtype: int64




```python
df.value_counts("employment_status")
```




    employment_status
    Employed         13007
    Self-employed     2923
    Unemployed        2113
    Retired           1176
    Student            781
    Name: count, dtype: int64




```python
df.describe()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_paid_back</th>
      <th>monthly_income</th>
      <th>debt_to_income_ratio</th>
      <th>credit_score</th>
      <th>loan_amount</th>
      <th>interest_rate</th>
      <th>loan_term</th>
      <th>installment</th>
      <th>num_of_open_accounts</th>
      <th>total_credit_limit</th>
      <th>current_balance</th>
      <th>delinquency_history</th>
      <th>public_records</th>
      <th>num_of_delinquencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>20000.000000</td>
      <td>20000.000000</td>
      <td>20000.000000</td>
      <td>20000.00000</td>
      <td>20000.000000</td>
      <td>20000.000000</td>
      <td>20000.00000</td>
      <td>20000.000000</td>
      <td>20000.000000</td>
      <td>20000.000000</td>
      <td>20000.000000</td>
      <td>20000.000000</td>
      <td>20000.000000</td>
      <td>20000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>0.799900</td>
      <td>3629.136466</td>
      <td>0.177496</td>
      <td>679.25695</td>
      <td>15129.300909</td>
      <td>12.400627</td>
      <td>43.22280</td>
      <td>455.625794</td>
      <td>5.011800</td>
      <td>48649.824769</td>
      <td>24333.394631</td>
      <td>1.990150</td>
      <td>0.061800</td>
      <td>2.489150</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.400085</td>
      <td>2389.048326</td>
      <td>0.105108</td>
      <td>69.63858</td>
      <td>8605.405513</td>
      <td>2.442729</td>
      <td>11.00838</td>
      <td>274.622125</td>
      <td>2.244529</td>
      <td>32423.378128</td>
      <td>22313.845395</td>
      <td>1.474945</td>
      <td>0.285105</td>
      <td>1.631384</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>500.000000</td>
      <td>0.010000</td>
      <td>373.00000</td>
      <td>500.000000</td>
      <td>3.140000</td>
      <td>36.00000</td>
      <td>9.430000</td>
      <td>0.000000</td>
      <td>6157.800000</td>
      <td>496.350000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.000000</td>
      <td>2021.730000</td>
      <td>0.100000</td>
      <td>632.00000</td>
      <td>8852.695000</td>
      <td>10.740000</td>
      <td>36.00000</td>
      <td>253.910000</td>
      <td>3.000000</td>
      <td>27180.492500</td>
      <td>9592.572500</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.000000</td>
      <td>3048.770000</td>
      <td>0.160000</td>
      <td>680.00000</td>
      <td>14946.170000</td>
      <td>12.400000</td>
      <td>36.00000</td>
      <td>435.595000</td>
      <td>5.000000</td>
      <td>40241.615000</td>
      <td>18334.555000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1.000000</td>
      <td>4556.495000</td>
      <td>0.240000</td>
      <td>727.00000</td>
      <td>20998.867500</td>
      <td>14.002500</td>
      <td>60.00000</td>
      <td>633.595000</td>
      <td>6.000000</td>
      <td>60361.257500</td>
      <td>31743.327500</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.000000</td>
      <td>33333.330000</td>
      <td>0.670000</td>
      <td>850.00000</td>
      <td>49039.690000</td>
      <td>22.510000</td>
      <td>60.00000</td>
      <td>1685.400000</td>
      <td>15.000000</td>
      <td>454394.190000</td>
      <td>352177.900000</td>
      <td>11.000000</td>
      <td>2.000000</td>
      <td>11.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(f"Minimum loan Amount: {min(df["loan_amount"])}")
```

    Minimum loan Amount: 500.0
    


```python
print(f"Maximum loan Amount: {max(df["loan_amount"])}")
```

    Maximum loan Amount: 49039.69
    


```python
print(df.isna().sum())
```

    loan_paid_back          0
    education_level         0
    monthly_income          0
    employment_status       0
    debt_to_income_ratio    0
    credit_score            0
    loan_amount             0
    interest_rate           0
    loan_term               0
    installment             0
    num_of_open_accounts    0
    total_credit_limit      0
    current_balance         0
    delinquency_history     0
    public_records          0
    num_of_delinquencies    0
    dtype: int64
    


```python
df.drop_duplicates()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_paid_back</th>
      <th>education_level</th>
      <th>monthly_income</th>
      <th>employment_status</th>
      <th>debt_to_income_ratio</th>
      <th>credit_score</th>
      <th>loan_amount</th>
      <th>interest_rate</th>
      <th>loan_term</th>
      <th>installment</th>
      <th>num_of_open_accounts</th>
      <th>total_credit_limit</th>
      <th>current_balance</th>
      <th>delinquency_history</th>
      <th>public_records</th>
      <th>num_of_delinquencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Master's</td>
      <td>2020.02</td>
      <td>Employed</td>
      <td>0.07</td>
      <td>743</td>
      <td>17173.72</td>
      <td>13.39</td>
      <td>36</td>
      <td>581.88</td>
      <td>7</td>
      <td>40833.47</td>
      <td>24302.07</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Bachelor's</td>
      <td>1681.08</td>
      <td>Employed</td>
      <td>0.22</td>
      <td>531</td>
      <td>22663.89</td>
      <td>17.81</td>
      <td>60</td>
      <td>573.17</td>
      <td>5</td>
      <td>27968.01</td>
      <td>10803.01</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>High School</td>
      <td>2181.82</td>
      <td>Employed</td>
      <td>0.23</td>
      <td>779</td>
      <td>3631.36</td>
      <td>9.53</td>
      <td>60</td>
      <td>76.32</td>
      <td>2</td>
      <td>15502.25</td>
      <td>4505.44</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>High School</td>
      <td>989.49</td>
      <td>Employed</td>
      <td>0.26</td>
      <td>809</td>
      <td>14939.23</td>
      <td>7.99</td>
      <td>36</td>
      <td>468.07</td>
      <td>7</td>
      <td>18157.79</td>
      <td>5525.63</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>Other</td>
      <td>2110.54</td>
      <td>Employed</td>
      <td>0.26</td>
      <td>663</td>
      <td>16551.71</td>
      <td>15.20</td>
      <td>60</td>
      <td>395.50</td>
      <td>1</td>
      <td>17467.56</td>
      <td>3593.91</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>19995</th>
      <td>0</td>
      <td>Bachelor's</td>
      <td>3303.34</td>
      <td>Employed</td>
      <td>0.28</td>
      <td>691</td>
      <td>16322.23</td>
      <td>15.05</td>
      <td>36</td>
      <td>566.22</td>
      <td>2</td>
      <td>23748.10</td>
      <td>5801.45</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>19996</th>
      <td>1</td>
      <td>Bachelor's</td>
      <td>2671.91</td>
      <td>Employed</td>
      <td>0.37</td>
      <td>758</td>
      <td>16697.34</td>
      <td>11.89</td>
      <td>36</td>
      <td>553.71</td>
      <td>8</td>
      <td>49929.65</td>
      <td>40901.31</td>
      <td>3</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>19997</th>
      <td>1</td>
      <td>Master's</td>
      <td>1553.50</td>
      <td>Student</td>
      <td>0.11</td>
      <td>751</td>
      <td>23924.78</td>
      <td>10.06</td>
      <td>36</td>
      <td>772.66</td>
      <td>3</td>
      <td>13137.57</td>
      <td>5075.67</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>19998</th>
      <td>1</td>
      <td>Master's</td>
      <td>1848.45</td>
      <td>Retired</td>
      <td>0.28</td>
      <td>646</td>
      <td>16920.13</td>
      <td>16.06</td>
      <td>36</td>
      <td>595.36</td>
      <td>5</td>
      <td>19580.82</td>
      <td>3876.16</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>19999</th>
      <td>0</td>
      <td>Other</td>
      <td>1978.14</td>
      <td>Employed</td>
      <td>0.23</td>
      <td>630</td>
      <td>15769.75</td>
      <td>13.07</td>
      <td>36</td>
      <td>531.88</td>
      <td>8</td>
      <td>43013.59</td>
      <td>12753.03</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>20000 rows × 16 columns</p>
</div>




```python
plt.figure(figsize=(10,6))
sns.countplot(df, x="loan_paid_back",color = 'orange')
plt.title("Count Plot of Loan Paid Back")  
plt.xlabel("Loan Paid Back")
plt.show()
```


    
![png](output_10_0.png)
    



```python

plt.figure(figsize=(10,6))
sns.boxplot(df, x="monthly_income")
plt.title("Boxplot of Monthly Income")  
plt.xlabel("Monthly Income")
plt.show()
```


    
![png](output_11_0.png)
    



```python
seventyfive_percentile_mothlyincome=df["monthly_income"].quantile(0.75)
```


```python
tewntyfive_percentile_mothlyincome=df["monthly_income"].quantile(0.25)
```


```python
IQR=seventyfive_percentile_mothlyincome-tewntyfive_percentile_mothlyincome
print(IQR)
```

    2534.765
    


```python
upper_outlier = seventyfive_percentile_mothlyincome + (1.5*IQR)
lower_outlier = tewntyfive_percentile_mothlyincome - (1.5*IQR)
print(upper_outlier, lower_outlier)
```

    8358.6425 -1780.4175
    


```python
no_outliers= df[(df["monthly_income"]>=lower_outlier) & (df["monthly_income"]<=upper_outlier)].copy()
print(no_outliers)
```

           loan_paid_back education_level  monthly_income employment_status  \
    0                   1        Master's         2020.02          Employed   
    1                   1      Bachelor's         1681.08          Employed   
    2                   1     High School         2181.82          Employed   
    3                   1     High School          989.49          Employed   
    4                   1           Other         2110.54          Employed   
    ...               ...             ...             ...               ...   
    19995               0      Bachelor's         3303.34          Employed   
    19996               1      Bachelor's         2671.91          Employed   
    19997               1        Master's         1553.50           Student   
    19998               1        Master's         1848.45           Retired   
    19999               0           Other         1978.14          Employed   
    
           debt_to_income_ratio  credit_score  loan_amount  interest_rate  \
    0                      0.07           743     17173.72          13.39   
    1                      0.22           531     22663.89          17.81   
    2                      0.23           779      3631.36           9.53   
    3                      0.26           809     14939.23           7.99   
    4                      0.26           663     16551.71          15.20   
    ...                     ...           ...          ...            ...   
    19995                  0.28           691     16322.23          15.05   
    19996                  0.37           758     16697.34          11.89   
    19997                  0.11           751     23924.78          10.06   
    19998                  0.28           646     16920.13          16.06   
    19999                  0.23           630     15769.75          13.07   
    
           loan_term  installment  num_of_open_accounts  total_credit_limit  \
    0             36       581.88                     7            40833.47   
    1             60       573.17                     5            27968.01   
    2             60        76.32                     2            15502.25   
    3             36       468.07                     7            18157.79   
    4             60       395.50                     1            17467.56   
    ...          ...          ...                   ...                 ...   
    19995         36       566.22                     2            23748.10   
    19996         36       553.71                     8            49929.65   
    19997         36       772.66                     3            13137.57   
    19998         36       595.36                     5            19580.82   
    19999         36       531.88                     8            43013.59   
    
           current_balance  delinquency_history  public_records  \
    0             24302.07                    1               0   
    1             10803.01                    1               0   
    2              4505.44                    0               0   
    3              5525.63                    4               0   
    4              3593.91                    2               0   
    ...                ...                  ...             ...   
    19995          5801.45                    1               0   
    19996         40901.31                    3               0   
    19997          5075.67                    1               0   
    19998          3876.16                    4               0   
    19999         12753.03                    2               0   
    
           num_of_delinquencies  
    0                         1  
    1                         3  
    2                         0  
    3                         5  
    4                         2  
    ...                     ...  
    19995                     4  
    19996                     3  
    19997                     2  
    19998                     5  
    19999                     2  
    
    [19076 rows x 16 columns]
    


```python
print(no_outliers["monthly_income"].describe())
```

    count    19076.000000
    mean      3275.431041
    std       1679.810750
    min        500.000000
    25%       1981.797500
    50%       2940.785000
    75%       4288.657500
    max       8357.400000
    Name: monthly_income, dtype: float64
    


```python
plt.figure(figsize=(10,6))
sns.histplot(df, x="monthly_income",bins=50 ,color = 'green', kde=True)
plt.title("Histogram of Monthly Income with outliers")
plt.xlabel("Monthly Income")
plt.ylabel("Count")
```




    Text(0, 0.5, 'Count')




    
![png](output_18_1.png)
    



```python
plt.figure(figsize=(10,6))
sns.histplot(no_outliers, x="monthly_income",bins=50 ,color = 'green', kde=True)
plt.title("Histogram of Monthly Income without outliers")
plt.xlabel("Monthly Income")
plt.ylabel("Count")
```




    Text(0, 0.5, 'Count')




    
![png](output_19_1.png)
    



```python
plt.figure(figsize=(10,6))
sns.histplot(no_outliers, x="loan_amount",bins=50 ,color = 'red', kde=True)
plt.title("Histogram of Loan amount")
plt.xlabel("Loan Amount")
plt.ylabel("Count")
```




    Text(0, 0.5, 'Count')




    
![png](output_20_1.png)
    



```python
df["loan_amount"].describe()
```




    count    20000.000000
    mean     15129.300909
    std       8605.405513
    min        500.000000
    25%       8852.695000
    50%      14946.170000
    75%      20998.867500
    max      49039.690000
    Name: loan_amount, dtype: float64




```python
plt.figure(figsize=(10,6))
sns.histplot(df, x="credit_score",bins=50 ,color = 'blue', kde=True, line_kws={'color': 'black'})
plt.title("Histogram of Credit Score")
plt.xlabel("Credit Score")
plt.ylabel("Density")
```




    Text(0, 0.5, 'Density')




    
![png](output_22_1.png)
    



```python
skewness = no_outliers.skew(numeric_only=True)
print(skewness)
```

    loan_paid_back         -1.503481
    monthly_income          0.780185
    debt_to_income_ratio    0.789635
    credit_score           -0.073550
    loan_amount             0.255350
    interest_rate           0.026442
    loan_term               0.872613
    installment             0.469447
    num_of_open_accounts    0.442304
    total_credit_limit      1.163923
    current_balance         1.569846
    delinquency_history     0.824823
    public_records          5.018849
    num_of_delinquencies    0.720254
    dtype: float64
    


```python
no_outliers["income_to_loan_ratio"]=((no_outliers["monthly_income"]*12)/(no_outliers["loan_amount"]))

no_outliers["utilization_ratio"]=((no_outliers["current_balance"]*12)/(no_outliers["total_credit_limit"]))
```


```python

no_outliers['education_encoded'] =  LabelEncoder().fit_transform(no_outliers['education_level'])
```


```python
no_outliers['employment_encoded'] =  LabelEncoder().fit_transform(no_outliers['employment_status'])
```


```python
no_outliers.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_paid_back</th>
      <th>education_level</th>
      <th>monthly_income</th>
      <th>employment_status</th>
      <th>debt_to_income_ratio</th>
      <th>credit_score</th>
      <th>loan_amount</th>
      <th>interest_rate</th>
      <th>loan_term</th>
      <th>installment</th>
      <th>num_of_open_accounts</th>
      <th>total_credit_limit</th>
      <th>current_balance</th>
      <th>delinquency_history</th>
      <th>public_records</th>
      <th>num_of_delinquencies</th>
      <th>income_to_loan_ratio</th>
      <th>utilization_ratio</th>
      <th>education_encoded</th>
      <th>employment_encoded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Master's</td>
      <td>2020.02</td>
      <td>Employed</td>
      <td>0.07</td>
      <td>743</td>
      <td>17173.72</td>
      <td>13.39</td>
      <td>36</td>
      <td>581.88</td>
      <td>7</td>
      <td>40833.47</td>
      <td>24302.07</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1.411473</td>
      <td>7.141809</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Bachelor's</td>
      <td>1681.08</td>
      <td>Employed</td>
      <td>0.22</td>
      <td>531</td>
      <td>22663.89</td>
      <td>17.81</td>
      <td>60</td>
      <td>573.17</td>
      <td>5</td>
      <td>27968.01</td>
      <td>10803.01</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0.890093</td>
      <td>4.635157</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>High School</td>
      <td>2181.82</td>
      <td>Employed</td>
      <td>0.23</td>
      <td>779</td>
      <td>3631.36</td>
      <td>9.53</td>
      <td>60</td>
      <td>76.32</td>
      <td>2</td>
      <td>15502.25</td>
      <td>4505.44</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>7.209927</td>
      <td>3.487576</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>High School</td>
      <td>989.49</td>
      <td>Employed</td>
      <td>0.26</td>
      <td>809</td>
      <td>14939.23</td>
      <td>7.99</td>
      <td>36</td>
      <td>468.07</td>
      <td>7</td>
      <td>18157.79</td>
      <td>5525.63</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
      <td>0.794812</td>
      <td>3.651742</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>Other</td>
      <td>2110.54</td>
      <td>Employed</td>
      <td>0.26</td>
      <td>663</td>
      <td>16551.71</td>
      <td>15.20</td>
      <td>60</td>
      <td>395.50</td>
      <td>1</td>
      <td>17467.56</td>
      <td>3593.91</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>1.530143</td>
      <td>2.468972</td>
      <td>3</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



no_outliers.to_csv("tranform_dataset.csv")


```python
no_outliers.corr(numeric_only=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_paid_back</th>
      <th>monthly_income</th>
      <th>debt_to_income_ratio</th>
      <th>credit_score</th>
      <th>loan_amount</th>
      <th>interest_rate</th>
      <th>loan_term</th>
      <th>installment</th>
      <th>num_of_open_accounts</th>
      <th>total_credit_limit</th>
      <th>current_balance</th>
      <th>delinquency_history</th>
      <th>public_records</th>
      <th>num_of_delinquencies</th>
      <th>income_to_loan_ratio</th>
      <th>utilization_ratio</th>
      <th>education_encoded</th>
      <th>employment_encoded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>loan_paid_back</th>
      <td>1.000000</td>
      <td>0.019801</td>
      <td>-0.222571</td>
      <td>0.202053</td>
      <td>-0.003618</td>
      <td>-0.113965</td>
      <td>-0.003623</td>
      <td>-0.010736</td>
      <td>0.003875</td>
      <td>0.010068</td>
      <td>0.003278</td>
      <td>-0.083413</td>
      <td>0.005399</td>
      <td>-0.070747</td>
      <td>0.005966</td>
      <td>-0.005898</td>
      <td>0.014446</td>
      <td>-0.489946</td>
    </tr>
    <tr>
      <th>monthly_income</th>
      <td>0.019801</td>
      <td>1.000000</td>
      <td>-0.006746</td>
      <td>0.005617</td>
      <td>-0.003758</td>
      <td>-0.005073</td>
      <td>-0.006311</td>
      <td>-0.003457</td>
      <td>0.002780</td>
      <td>0.842452</td>
      <td>0.570038</td>
      <td>0.003121</td>
      <td>-0.001050</td>
      <td>0.001463</td>
      <td>0.212248</td>
      <td>0.003826</td>
      <td>-0.000182</td>
      <td>-0.000054</td>
    </tr>
    <tr>
      <th>debt_to_income_ratio</th>
      <td>-0.222571</td>
      <td>-0.006746</td>
      <td>1.000000</td>
      <td>-0.021741</td>
      <td>-0.004013</td>
      <td>0.014475</td>
      <td>0.005474</td>
      <td>-0.002954</td>
      <td>-0.005415</td>
      <td>-0.001166</td>
      <td>-0.001496</td>
      <td>0.227326</td>
      <td>-0.001707</td>
      <td>0.209722</td>
      <td>-0.005432</td>
      <td>-0.002116</td>
      <td>-0.005339</td>
      <td>0.011981</td>
    </tr>
    <tr>
      <th>credit_score</th>
      <td>0.202053</td>
      <td>0.005617</td>
      <td>-0.021741</td>
      <td>1.000000</td>
      <td>0.007603</td>
      <td>-0.569435</td>
      <td>0.004303</td>
      <td>-0.030968</td>
      <td>-0.003292</td>
      <td>-0.002704</td>
      <td>-0.008101</td>
      <td>-0.162587</td>
      <td>0.003588</td>
      <td>-0.142789</td>
      <td>-0.001167</td>
      <td>-0.011766</td>
      <td>-0.001462</td>
      <td>0.002165</td>
    </tr>
    <tr>
      <th>loan_amount</th>
      <td>-0.003618</td>
      <td>-0.003758</td>
      <td>-0.004013</td>
      <td>0.007603</td>
      <td>1.000000</td>
      <td>-0.006092</td>
      <td>0.001611</td>
      <td>0.945011</td>
      <td>-0.005376</td>
      <td>-0.001485</td>
      <td>-0.008343</td>
      <td>-0.006647</td>
      <td>0.002117</td>
      <td>-0.008046</td>
      <td>-0.477663</td>
      <td>-0.004393</td>
      <td>-0.003510</td>
      <td>0.010896</td>
    </tr>
    <tr>
      <th>interest_rate</th>
      <td>-0.113965</td>
      <td>-0.005073</td>
      <td>0.014475</td>
      <td>-0.569435</td>
      <td>-0.006092</td>
      <td>1.000000</td>
      <td>-0.004115</td>
      <td>0.060932</td>
      <td>0.001876</td>
      <td>0.000677</td>
      <td>0.005138</td>
      <td>0.091634</td>
      <td>-0.003741</td>
      <td>0.078712</td>
      <td>0.010002</td>
      <td>0.009797</td>
      <td>0.001437</td>
      <td>0.001008</td>
    </tr>
    <tr>
      <th>loan_term</th>
      <td>-0.003623</td>
      <td>-0.006311</td>
      <td>0.005474</td>
      <td>0.004303</td>
      <td>0.001611</td>
      <td>-0.004115</td>
      <td>1.000000</td>
      <td>-0.274990</td>
      <td>0.015386</td>
      <td>-0.002951</td>
      <td>-0.000285</td>
      <td>-0.002394</td>
      <td>-0.003170</td>
      <td>-0.002597</td>
      <td>-0.002119</td>
      <td>0.001168</td>
      <td>0.008283</td>
      <td>0.002489</td>
    </tr>
    <tr>
      <th>installment</th>
      <td>-0.010736</td>
      <td>-0.003457</td>
      <td>-0.002954</td>
      <td>-0.030968</td>
      <td>0.945011</td>
      <td>0.060932</td>
      <td>-0.274990</td>
      <td>1.000000</td>
      <td>-0.009226</td>
      <td>-0.000905</td>
      <td>-0.007391</td>
      <td>0.001220</td>
      <td>0.004729</td>
      <td>-0.001148</td>
      <td>-0.450918</td>
      <td>-0.004639</td>
      <td>-0.007221</td>
      <td>0.009685</td>
    </tr>
    <tr>
      <th>num_of_open_accounts</th>
      <td>0.003875</td>
      <td>0.002780</td>
      <td>-0.005415</td>
      <td>-0.003292</td>
      <td>-0.005376</td>
      <td>0.001876</td>
      <td>0.015386</td>
      <td>-0.009226</td>
      <td>1.000000</td>
      <td>0.102172</td>
      <td>0.066680</td>
      <td>-0.000318</td>
      <td>-0.008897</td>
      <td>-0.003268</td>
      <td>-0.008094</td>
      <td>0.000687</td>
      <td>0.010244</td>
      <td>0.000554</td>
    </tr>
    <tr>
      <th>total_credit_limit</th>
      <td>0.010068</td>
      <td>0.842452</td>
      <td>-0.001166</td>
      <td>-0.002704</td>
      <td>-0.001485</td>
      <td>0.000677</td>
      <td>-0.002951</td>
      <td>-0.000905</td>
      <td>0.102172</td>
      <td>1.000000</td>
      <td>0.673074</td>
      <td>0.002854</td>
      <td>0.002314</td>
      <td>0.003069</td>
      <td>0.177502</td>
      <td>-0.002482</td>
      <td>-0.006075</td>
      <td>-0.000430</td>
    </tr>
    <tr>
      <th>current_balance</th>
      <td>0.003278</td>
      <td>0.570038</td>
      <td>-0.001496</td>
      <td>-0.008101</td>
      <td>-0.008343</td>
      <td>0.005138</td>
      <td>-0.000285</td>
      <td>-0.007391</td>
      <td>0.066680</td>
      <td>0.673074</td>
      <td>1.000000</td>
      <td>0.004341</td>
      <td>-0.002354</td>
      <td>0.008308</td>
      <td>0.129031</td>
      <td>0.648715</td>
      <td>-0.002374</td>
      <td>0.003713</td>
    </tr>
    <tr>
      <th>delinquency_history</th>
      <td>-0.083413</td>
      <td>0.003121</td>
      <td>0.227326</td>
      <td>-0.162587</td>
      <td>-0.006647</td>
      <td>0.091634</td>
      <td>-0.002394</td>
      <td>0.001220</td>
      <td>-0.000318</td>
      <td>0.002854</td>
      <td>0.004341</td>
      <td>1.000000</td>
      <td>0.001683</td>
      <td>0.903351</td>
      <td>-0.002352</td>
      <td>0.004545</td>
      <td>0.003336</td>
      <td>0.000028</td>
    </tr>
    <tr>
      <th>public_records</th>
      <td>0.005399</td>
      <td>-0.001050</td>
      <td>-0.001707</td>
      <td>0.003588</td>
      <td>0.002117</td>
      <td>-0.003741</td>
      <td>-0.003170</td>
      <td>0.004729</td>
      <td>-0.008897</td>
      <td>0.002314</td>
      <td>-0.002354</td>
      <td>0.001683</td>
      <td>1.000000</td>
      <td>0.005856</td>
      <td>-0.006165</td>
      <td>-0.010095</td>
      <td>0.008239</td>
      <td>-0.008134</td>
    </tr>
    <tr>
      <th>num_of_delinquencies</th>
      <td>-0.070747</td>
      <td>0.001463</td>
      <td>0.209722</td>
      <td>-0.142789</td>
      <td>-0.008046</td>
      <td>0.078712</td>
      <td>-0.002597</td>
      <td>-0.001148</td>
      <td>-0.003268</td>
      <td>0.003069</td>
      <td>0.008308</td>
      <td>0.903351</td>
      <td>0.005856</td>
      <td>1.000000</td>
      <td>-0.008850</td>
      <td>0.005942</td>
      <td>-0.000615</td>
      <td>-0.004960</td>
    </tr>
    <tr>
      <th>income_to_loan_ratio</th>
      <td>0.005966</td>
      <td>0.212248</td>
      <td>-0.005432</td>
      <td>-0.001167</td>
      <td>-0.477663</td>
      <td>0.010002</td>
      <td>-0.002119</td>
      <td>-0.450918</td>
      <td>-0.008094</td>
      <td>0.177502</td>
      <td>0.129031</td>
      <td>-0.002352</td>
      <td>-0.006165</td>
      <td>-0.008850</td>
      <td>1.000000</td>
      <td>0.003482</td>
      <td>-0.005918</td>
      <td>-0.005893</td>
    </tr>
    <tr>
      <th>utilization_ratio</th>
      <td>-0.005898</td>
      <td>0.003826</td>
      <td>-0.002116</td>
      <td>-0.011766</td>
      <td>-0.004393</td>
      <td>0.009797</td>
      <td>0.001168</td>
      <td>-0.004639</td>
      <td>0.000687</td>
      <td>-0.002482</td>
      <td>0.648715</td>
      <td>0.004545</td>
      <td>-0.010095</td>
      <td>0.005942</td>
      <td>0.003482</td>
      <td>1.000000</td>
      <td>-0.000294</td>
      <td>0.005680</td>
    </tr>
    <tr>
      <th>education_encoded</th>
      <td>0.014446</td>
      <td>-0.000182</td>
      <td>-0.005339</td>
      <td>-0.001462</td>
      <td>-0.003510</td>
      <td>0.001437</td>
      <td>0.008283</td>
      <td>-0.007221</td>
      <td>0.010244</td>
      <td>-0.006075</td>
      <td>-0.002374</td>
      <td>0.003336</td>
      <td>0.008239</td>
      <td>-0.000615</td>
      <td>-0.005918</td>
      <td>-0.000294</td>
      <td>1.000000</td>
      <td>-0.009679</td>
    </tr>
    <tr>
      <th>employment_encoded</th>
      <td>-0.489946</td>
      <td>-0.000054</td>
      <td>0.011981</td>
      <td>0.002165</td>
      <td>0.010896</td>
      <td>0.001008</td>
      <td>0.002489</td>
      <td>0.009685</td>
      <td>0.000554</td>
      <td>-0.000430</td>
      <td>0.003713</td>
      <td>0.000028</td>
      <td>-0.008134</td>
      <td>-0.004960</td>
      <td>-0.005893</td>
      <td>0.005680</td>
      <td>-0.009679</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(20,8))
sns.heatmap(no_outliers.corr(numeric_only=True), annot=True)
plt.title("Correlation between the numerical variables")
plt.show()
```


    
![png](output_30_0.png)
    



```python
sns.pairplot(data=no_outliers)
plt.show()
```


    
![png](output_31_0.png)
    



```python
X=no_outliers[["monthly_income", 
"debt_to_income_ratio",
"credit_score",
"loan_amount",
"interest_rate",
"loan_term",
"installment",
"num_of_open_accounts",
"total_credit_limit",
"current_balance",
"delinquency_history",
"public_records",
"num_of_delinquencies",
"income_to_loan_ratio",
"utilization_ratio",
"education_encoded",
"employment_encoded"]]

y=no_outliers["loan_paid_back"]
```


```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.25,
    random_state=15
)
```


```python


scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
```


```python
lr=LogisticRegression()
lr.fit(X_train_scaled, y_train)
```




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;LogisticRegression<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.linear_model.LogisticRegression.html">?<span>Documentation for LogisticRegression</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>LogisticRegression()</pre></div> </div></div></div></div>




```python
y_pred = lr.predict(X_test_scaled)
y_prob = lr.predict_proba(X_test_scaled)[:, 1]

```


```python

```


```python

X = sm.add_constant(X)
model = sm.Logit(y, X)
result = model.fit()

print(result.summary())

```

    Optimization terminated successfully.
             Current function value: 0.334290
             Iterations 7
                               Logit Regression Results                           
    ==============================================================================
    Dep. Variable:         loan_paid_back   No. Observations:                19076
    Model:                          Logit   Df Residuals:                    19058
    Method:                           MLE   Df Model:                           17
    Date:                Tue, 13 Jan 2026   Pseudo R-squ.:                  0.3312
    Time:                        21:53:51   Log-Likelihood:                -6376.9
    converged:                       True   LL-Null:                       -9534.3
    Covariance Type:            nonrobust   LLR p-value:                     0.000
    ========================================================================================
                               coef    std err          z      P>|z|      [0.025      0.975]
    ----------------------------------------------------------------------------------------
    const                   -3.6606      0.417     -8.786      0.000      -4.477      -2.844
    monthly_income        7.139e-05   2.61e-05      2.737      0.006    2.03e-05       0.000
    debt_to_income_ratio    -7.0442      0.220    -32.006      0.000      -7.476      -6.613
    credit_score             0.0112      0.000     26.702      0.000       0.010       0.012
    loan_amount           7.049e-06   1.57e-05      0.448      0.654   -2.38e-05    3.79e-05
    interest_rate            0.0124      0.012      1.050      0.294      -0.011       0.036
    loan_term               -0.0028      0.004     -0.685      0.493      -0.011       0.005
    installment             -0.0002      0.001     -0.484      0.629      -0.001       0.001
    num_of_open_accounts     0.0042      0.010      0.415      0.678      -0.016       0.024
    total_credit_limit   -2.945e-06   2.61e-06     -1.128      0.259   -8.06e-06    2.17e-06
    current_balance       5.251e-07   3.71e-06      0.142      0.887   -6.74e-06    7.79e-06
    delinquency_history     -0.0423      0.036     -1.163      0.245      -0.114       0.029
    public_records           0.0089      0.081      0.109      0.913      -0.150       0.168
    num_of_delinquencies     0.0361      0.033      1.091      0.275      -0.029       0.101
    income_to_loan_ratio    -0.0005      0.001     -0.357      0.721      -0.003       0.002
    utilization_ratio       -0.0053      0.015     -0.348      0.728      -0.036       0.025
    education_encoded        0.0362      0.020      1.778      0.075      -0.004       0.076
    employment_encoded      -0.9549      0.016    -58.631      0.000      -0.987      -0.923
    ========================================================================================
    


```python


print("\nROC-AUC Score:")
print(roc_auc_score(y_test, y_prob))

```

    
    ROC-AUC Score:
    0.8551456344480971
    


```python

```
